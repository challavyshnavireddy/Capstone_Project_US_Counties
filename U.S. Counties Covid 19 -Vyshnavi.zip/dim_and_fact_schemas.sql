
CREATE TABLE DimDate (
    date_id INT PRIMARY KEY,
    Date DATEtime2,
    year INT,
    month INT,
    season VARCHAR(20)
);

CREATE TABLE DimLocation (
    location_id INT PRIMARY KEY,
    county_name VARCHAR(100),
    state_name VARCHAR(50),
    fips_id INT not null,
    create_date DATETIME2 ,
    update_date DATETIME2 
);

CREATE TABLE FactData (
    id INT PRIMARY KEY,              
    date_id INT NOT NULL,                 
    location_id INT NOT NULL,             
    FOREIGN KEY (date_id) REFERENCES DimDate(date_id),
    FOREIGN KEY (location_id) REFERENCES DimLocation(location_id),
	cases int,
	deaths int
);

