from flask import Flask, render_template,jsonify,request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os
import plotly
import plotly.graph_objs as go
import plotly.express as px
import json
import pandas as pd
from sqlalchemy.sql import text
import matplotlib.pyplot as plt
import io  
import base64  
import pandas as pd 





app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mssql+pyodbc://INFA_REP:INFA_REP@localhost/hr?driver=ODBC+Driver+17+for+SQL+Server'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  
app.config['SECRET_KEY'] = 'secret_key'  
db = SQLAlchemy(app)
migrate = Migrate(app, db)



class DimDate(db.Model):
    __tablename__ = 'DimDate'
    date_id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime)
    year = db.Column(db.Integer)
    month = db.Column(db.Integer)
    season = db.Column(db.String(50))
class DimLocation(db.Model):
    __tablename__ = 'DimLocation'
    location_id = db.Column(db.Integer, primary_key=True)
    country_name = db.Column(db.String(255))
    state_name = db.Column(db.String(255))
    fips_id = db.Column(db.Integer)
class FactData(db.Model):
    __tablename__ = 'FactData'
    id = db.Column(db.Integer, primary_key=True)
    date_id = db.Column(db.Integer, db.ForeignKey('DimDate.date_id'))
    location_id = db.Column(db.Integer, db.ForeignKey('DimLocation.location_id'))
    cases = db.Column(db.Integer)
    deaths = db.Column(db.Integer)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/visualize-cases')
def visualize_cases():
    query_season = """
    SELECT 
        DimDate.season,
        SUM(FactData.cases) AS total_cases
    FROM 
        DimDate
    JOIN 
        FactData ON DimDate.date_id = FactData.date_id
    GROUP BY 
        DimDate.season
    ORDER BY 
        DimDate.season;
    """
    cases_by_season = db.session.execute(text(query_season)).fetchall()
    data_season = [{'season': row[0], 'total_cases': row[1]} for row in cases_by_season]
    query_month = """
    SELECT 
        MONTH(DimDate.date) AS month,
        SUM(FactData.cases) AS total_cases
    FROM 
        DimDate
    JOIN 
        FactData ON DimDate.date_id = FactData.date_id
    GROUP BY 
        MONTH(DimDate.date)
    ORDER BY 
        month;
    """
    cases_by_month = db.session.execute(text(query_month)).fetchall()
    data_month = [{'month': row[0], 'total_cases': row[1]} for row in cases_by_month]
    for record in data_month:
        if record['month'] in [12, 1, 2]:
            record['season'] = 'Winter'
        else:
            record['season'] = 'Other'
    fig_season = px.bar(
        data_season,
        x='season',
        y='total_cases',
        title='COVID Cases by Season',
        labels={'season': 'Season', 'total_cases': 'Total Cases'},
        template='plotly_dark',
    )
    fig_month = px.bar(
        data_month,
        x='month',
        y='total_cases',
        color='season',  
        title='COVID Cases by Month',
        labels={'month': 'Month', 'total_cases': 'Total Cases'},
        template='plotly_dark',
    )
    graphJSON_season = json.dumps(fig_season, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSON_month = json.dumps(fig_month, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('visualize_cases.html', graphJSON_season=graphJSON_season, graphJSON_month=graphJSON_month)



@app.route('/cases-deaths-percent')
def cases_deaths_percent():
    query_2020 = text("""
    SELECT 
        DimLocation.country_name,
        DimLocation.state_name,
        SUM(FactData.cases) AS total_cases,
        SUM(FactData.deaths) AS total_deaths,
        CASE 
            WHEN SUM(FactData.cases) > 0 THEN (SUM(FactData.deaths) * 100.0 / SUM(FactData.cases))
            ELSE 0
        END AS death_percent
    FROM 
        DimLocation
    JOIN 
        FactData ON DimLocation.location_id = FactData.location_id
    JOIN 
        DimDate ON DimDate.date_id = FactData.date_id
    WHERE 
        DimDate.year = 2020
    GROUP BY 
        DimLocation.country_name, DimLocation.state_name
    ORDER BY 
        death_percent DESC;
    """)
    data_2020 = db.session.execute(query_2020).fetchall()
    query_2021 = text("""
    SELECT 
        DimLocation.country_name,
        DimLocation.state_name,
        SUM(FactData.cases) AS total_cases,
        SUM(FactData.deaths) AS total_deaths,
        CASE 
            WHEN SUM(FactData.cases) > 0 THEN (SUM(FactData.deaths) * 100.0 / SUM(FactData.cases))
            ELSE 0
        END AS death_percent
    FROM 
        DimLocation
    JOIN 
        FactData ON DimLocation.location_id = FactData.location_id
    JOIN 
        DimDate ON DimDate.date_id = FactData.date_id
    WHERE 
        DimDate.year = 2021
    GROUP BY 
        DimLocation.country_name, DimLocation.state_name
    ORDER BY 
        death_percent DESC;
    """)
    data_2021 = db.session.execute(query_2021).fetchall()
    sorted_data_2020 = sorted(data_2020, key=lambda x: x[4] if x[4] is not None else 0, reverse=True)[:15]
    sorted_data_2021 = sorted(data_2021, key=lambda x: x[4] if x[4] is not None else 0, reverse=True)[:15]
    countries_2020 = [f"{row[0]}, {row[1]}" for row in sorted_data_2020]
    death_percentages_2020 = [row[4] if row[4] is not None else 0 for row in sorted_data_2020]
    countries_2021 = [f"{row[0]}, {row[1]}" for row in sorted_data_2021]
    death_percentages_2021 = [row[4] if row[4] is not None else 0 for row in sorted_data_2021]

    fig_2020 = go.Figure(
        data=[go.Bar(x=countries_2020, y=death_percentages_2020, marker_color='red')],
        layout=go.Layout(
            title='Top 15 Areas with Highest Death Rates in 2020',
            xaxis=dict(title='County, State', tickangle=45),
            yaxis=dict(title='Death Rate (%)'),
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=False,
            xaxis_tickmode='array'
        )
    )

    fig_2021 = go.Figure(
        data=[go.Bar(x=countries_2021, y=death_percentages_2021, marker_color='blue')],
        layout=go.Layout(
            title='Top 15 Areas with Highest Death Rates in 2021',
            xaxis=dict(title='County, State', tickangle=45),
            yaxis=dict(title='Death Rate (%)'),
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=False,
            xaxis_tickmode='array'
        )
    )


    graphJSON_2020 = json.dumps(fig_2020, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSON_2021 = json.dumps(fig_2021, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template(
        'cases_deaths_percent.html',
        data_2020=sorted_data_2020,
        data_2021=sorted_data_2021,
        graphJSON_2020=graphJSON_2020,
        graphJSON_2021=graphJSON_2021
    )




@app.route('/percentage-cases-by-country', methods=['GET', 'POST'])
def percentage_cases_by_country():
    # Query to get distinct state names
    states_query = text(""" 
    SELECT DISTINCT state_name
    FROM DimLocation
    WHERE state_name IS NOT NULL
    AND EXISTS (
        SELECT 1
        FROM DimLocation AS D
        WHERE D.state_name = DimLocation.state_name
        AND D.country_name IS NOT NULL
    )
    ORDER BY state_name;
    """)
    states = db.session.execute(states_query).fetchall()
    states_list = [row[0] for row in states]
    if not states_list:
        return "No states with countries found."
    
    selected_state = request.form.get('state_name', states_list[0])

    query = text("""
    SELECT TOP 5
        DimLocation.country_name,
        SUM(FactData.cases) AS total_cases
    FROM 
        DimLocation
    JOIN 
        FactData ON DimLocation.location_id = FactData.location_id
    JOIN 
        DimDate ON FactData.date_id = DimDate.date_id
    WHERE 
        DimLocation.state_name = :state_name
        AND YEAR(DimDate.date) = :year
    GROUP BY 
        DimLocation.country_name
    ORDER BY 
        total_cases DESC;
    """)

    country_data_2020 = db.session.execute(query, {'state_name': selected_state, 'year': 2020}).fetchall()
    country_data_2021 = db.session.execute(query, {'state_name': selected_state, 'year': 2021}).fetchall()
    data_2020 = [{'country_name': row[0], 'total_cases': row[1]} for row in country_data_2020]
    df_2020 = pd.DataFrame(data_2020)
    data_2021 = [{'country_name': row[0], 'total_cases': row[1]} for row in country_data_2021]
    df_2021 = pd.DataFrame(data_2021)

    if len(df_2020) > 5:
        df_2020 = df_2020.head(5)
    if len(df_2021) > 5:
        df_2021 = df_2021.head(5)
    fig_cases_2020 = px.pie(
        df_2020,
        values='total_cases',
        names='country_name',
        title=f'Percentage of Cases by Counties in {selected_state} (2020)',
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    fig_cases_2021 = px.pie(
        df_2021,
        values='total_cases',
        names='country_name',
        title=f'Percentage of Cases by Counties in {selected_state} (2021)',
        color_discrete_sequence=px.colors.sequential.RdBu
    )

    graphJSON_cases_2020 = json.dumps(fig_cases_2020, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSON_cases_2021 = json.dumps(fig_cases_2021, cls=plotly.utils.PlotlyJSONEncoder)

    return render_template(
        'percentage_cases_by_country.html',
        graphJSON_cases_2020=graphJSON_cases_2020,
        graphJSON_cases_2021=graphJSON_cases_2021,
        states_list=states_list,
        selected_state=selected_state
    )



@app.route('/deaths_over_time')
def deaths_over_time():
    query = text("""
        SELECT DimDate.date, SUM(FactData.deaths) as total_deaths
        FROM FactData
        JOIN DimDate ON DimDate.date_id = FactData.date_id
        WHERE FactData.deaths IS NOT NULL
        GROUP BY DimDate.date
        ORDER BY DimDate.date ASC;
    """)
    results = db.session.execute(query).fetchall()
    
    dates = [result[0] for result in results]
    deaths = [result[1] for result in results]

    plt.figure(figsize=(10, 6))
    plt.plot(dates, deaths, label="Deaths", color='blue')
    plt.xlabel('Date')
    plt.ylabel('Deaths')
    plt.title('Deaths Over Time')
    plt.grid(True)
    plt.legend()

    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)

    graph_url = base64.b64encode(img.getvalue()).decode()
    plt.close()

    return render_template('graph.html', graph_url=graph_url)



if __name__ == '__main__':
    app.run(debug=True)
